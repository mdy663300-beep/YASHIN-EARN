import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createClient } from '@supabase/supabase-js';
import './style.css';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || '';
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || '';
const supabase = SUPABASE_URL && SUPABASE_ANON_KEY
  ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

const copy = {
  bn: {
    subtitle:'কাজ করুন • অগ্রগতি দেখুন', login:'লগইন', signup:'নতুন অ্যাকাউন্ট',
    email:'ইমেইল', password:'পাসওয়ার্ড', logout:'লগআউট', welcome:'স্বাগতম',
    free:'ফ্রি কাজ', premium:'প্রিমিয়াম প্যাকেজ', spin:'ফ্রি স্পিন',
    balance:'পয়েন্ট ব্যালেন্স', history:'লেনদেনের ইতিহাস', admin:'অ্যাডমিন',
    config:'Supabase সেটআপ বাকি', configText:'প্রথমে .env.example কপি করে .env বানান এবং Supabase URL ও anon key বসান।',
    disclaimer:'এটি প্রাথমিক সফটওয়্যার কাঠামো। বাস্তব ডিপোজিট, উত্তোলন, পুরস্কার বা আয় চালু নেই।',
    taskText:'অনুমোদিত কাজ এখানে দেখানো হবে। কাজ সম্পন্ন হলে সার্ভার যাচাই করে পয়েন্ট যোগ করবে।',
    premiumText:'প্যাকেজের মূল্য, সুবিধা, ঝুঁকি ও ফেরত নীতিমালা পরিষ্কারভাবে প্রকাশের পরেই চালু করুন।',
    spinText:'শুধু সক্রিয় প্রিমিয়াম প্যাকেজধারীরা নিয়ম অনুযায়ী স্পিন পাবেন। যোগ্যতা সার্ভার যাচাই করবে।',
    authError:'লগইন/রেজিস্ট্রেশন সম্পন্ন হয়নি। ইমেইল ও পাসওয়ার্ড যাচাই করুন।',
    noAccount:'এখনো অ্যাকাউন্ট নেই?'
  },
  en: {
    subtitle:'Complete tasks • Track progress', login:'Login', signup:'Create account',
    email:'Email', password:'Password', logout:'Log out', welcome:'Welcome',
    free:'Free tasks', premium:'Premium packages', spin:'Free spin',
    balance:'Points balance', history:'Transaction history', admin:'Admin',
    config:'Supabase setup required', configText:'Copy .env.example to .env and add your Supabase URL and anon key.',
    disclaimer:'Starter software only. Real deposits, withdrawals, rewards, or earnings are not enabled.',
    taskText:'Approved tasks will appear here. The server must verify completion before awarding points.',
    premiumText:'Eligible active premium members receive a ৳10 daily bonus under the published terms.',
    spinText:'Only users with an active premium package are eligible for spins. Eligibility must be checked server-side.',
    authError:'Authentication failed. Check your email and password.',
    noAccount:'New here?'
  }
};

function App(){
  const [lang,setLang]=useState('bn');
  const [session,setSession]=useState(null);
  const [email,setEmail]=useState('');
  const [password,setPassword]=useState('');
  const [isSignup,setIsSignup]=useState(false);
  const [message,setMessage]=useState('');
  const [busy,setBusy]=useState(false);
  const [profile,setProfile]=useState(null);
  const t=copy[lang];

  React.useEffect(()=>{
    if(!supabase) return;
    supabase.auth.getSession().then(({data})=>setSession(data.session));
    const {data:{subscription}}=supabase.auth.onAuthStateChange((_event,s)=>setSession(s));
    return ()=>subscription.unsubscribe();
  },[]);

  React.useEffect(()=>{
    let active=true;
    async function loadProfile(){
      if(!supabase || !session?.user?.id){setProfile(null);return;}
      const {data,error}=await supabase.from('profiles').select('id,email,role,created_at').eq('id',session.user.id).maybeSingle();
      if(active) setProfile(error?null:data);
    }
    loadProfile();
    return ()=>{active=false;};
  },[session]);

  async function authenticate(e){
    e.preventDefault(); setBusy(true); setMessage('');
    if(!supabase){setMessage(t.configText);setBusy(false);return;}
    const result=isSignup
      ? await supabase.auth.signUp({email,password})
      : await supabase.auth.signInWithPassword({email,password});
    if(result.error) setMessage(t.authError);
    else setMessage(isSignup?'ইমেইল যাচাইয়ের নির্দেশনা দেখুন / Check your email to confirm.':'');
    setBusy(false);
  }
  async function logout(){if(supabase) await supabase.auth.signOut();setSession(null);}
  const userEmail=session?.user?.email || '';

  return <main className="shell">
    <header className="hero">
      <div className="brand">YASHIN<span>-EARN</span></div>
      <p>{t.subtitle}</p>
      <button className="lang" onClick={()=>setLang(lang==='bn'?'en':'bn')}>{lang==='bn'?'English':'বাংলা'}</button>
    </header>
    <div className="notice">{t.disclaimer}</div>
    {!session ? <section className="panel auth">
      <h2>{isSignup?t.signup:t.login}</h2>
      <form onSubmit={authenticate}>
        <label>{t.email}<input type="email" required value={email} onChange={e=>setEmail(e.target.value)} /></label>
        <label>{t.password}<input type="password" minLength="6" required value={password} onChange={e=>setPassword(e.target.value)} /></label>
        <button className="primary" disabled={busy}>{busy?'...':(isSignup?t.signup:t.login)}</button>
      </form>
      <button className="link" onClick={()=>setIsSignup(!isSignup)}>{t.noAccount} {isSignup?t.login:t.signup}</button>
      {message&&<p className="message">{message}</p>}
    </section> : <>
      <section className="welcome panel">
        <div><small>{t.welcome}</small><h2>{userEmail}</h2></div>
        <button onClick={logout}>{t.logout}</button>
      </section>
      {profile?.role==='owner' && <section className="panel owner-panel">
        <div className="owner-top"><span className="crown">♛</span><div><small>VIP OWNER</small><h2>YASHIN · মালিক</h2></div><span className="owner-tag">OWNER</span></div>
        <div className="owner-grid">
          <div><small>মালিক আইডি</small><strong>VIP-OWNER-001</strong></div>
          <div><small>মাসিক নির্ধারিত বেতন</small><strong>৳৩০,০০০</strong></div>
          <div><small>অ্যাডমিন অনুমতি</small><strong>শুধু মালিক</strong></div>
          <div><small>অ্যাকাউন্ট ভূমিকা</small><strong>OWNER</strong></div>
        </div>
        <p>অ্যাডমিন যোগ বা বাদ দেওয়ার সার্ভার-নিরাপদ ব্যবস্থাটি আলাদা অনুমোদিত অপারেশনের মাধ্যমে যুক্ত করতে হবে।</p>
      </section>}
      <section className="tiles">
        <article className="panel"><h3>{t.free}</h3><p>{t.taskText}</p></article>
        <article className="panel"><h3>{t.premium}</h3><p>{t.premiumText}</p><p><strong>দৈনিক বোনাস: ৳১০ / Daily bonus: ৳10</strong></p></article>
        <article className="panel"><h3>{t.spin}</h3><p>{t.spinText}</p><p><strong>শুধু সক্রিয় প্রিমিয়াম সদস্যদের জন্য</strong></p></article>
      </section>
      <section className="panel"><h3>{t.balance}</h3><p>—</p><small>পয়েন্ট ব্যালেন্স সার্ভার থেকে যুক্ত হলে এখানে দেখাবে।</small></section>
    </>}
    {!supabase&&<section className="panel setup"><h3>{t.config}</h3><p>{t.configText}</p></section>}
    <footer>© YASHIN-EARN · Starter project</footer>
  </main>;
}
createRoot(document.getElementById('root')).render(<App/>);
