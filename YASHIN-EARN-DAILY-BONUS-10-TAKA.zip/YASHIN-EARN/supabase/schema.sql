-- YASHIN-EARN starter schema. Run in Supabase SQL Editor.
-- Never expose the service_role key in the browser.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  role text not null default 'user' check (role in ('user','owner')),
  created_at timestamptz not null default now()
);

create table if not exists public.point_ledger (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  points integer not null check (points <> 0),
  reason text not null,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.point_ledger enable row level security;

-- Users can read only their own profile. They cannot update their role.
create policy "read own profile" on public.profiles
for select to authenticated using (auth.uid() = id);

-- Users can read only their own ledger. No client insert/update/delete policies.
create policy "read own ledger" on public.point_ledger
for select to authenticated using (auth.uid() = user_id);

-- New signups always receive the user role.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id,email,role)
  values (new.id,new.email,'user')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- IMPORTANT OWNER SETUP:
-- 1) Create your own account through the app.
-- 2) In Supabase SQL Editor, replace YOUR_AUTH_USER_UUID with your auth.users id.
-- 3) Run this one-time owner promotion using the trusted project owner account.
-- Do not add an admin/owner signup button to the public app.
-- update public.profiles set role='owner' where id='YOUR_AUTH_USER_UUID';


-- OWNER SECURITY NOTES:
-- The public app has no endpoint or policy that can promote a user to owner/admin.
-- Never add a client-side UPDATE policy for profiles.role.
-- Only the trusted project owner should run the one-time SQL below.
-- Replace the UUID with the owner's auth.users.id:
-- update public.profiles set role='owner' where id='YOUR_AUTH_USER_UUID';
--
-- Verify that exactly one owner exists after promotion:
-- select id, email, role from public.profiles where role='owner';
--
-- To keep owner-only administration safe, implement admin actions in Supabase
-- Edge Functions. Each function must verify the caller's JWT and check
-- profiles.role='owner' server-side before performing the action.
-- Do not rely on hiding buttons in the browser as access control.


-- Premium membership and daily bonus / spin eligibility.
-- These tables do not process payments or grant benefits automatically.
-- Grant benefits only through trusted server-side Edge Functions after
-- verifying a confirmed payment and the active membership period.

create table if not exists public.premium_memberships (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  package_code text not null,
  status text not null default 'pending'
    check (status in ('pending','active','expired','cancelled')),
  starts_at timestamptz,
  ends_at timestamptz,
  created_at timestamptz not null default now(),
  check (ends_at is null or starts_at is null or ends_at > starts_at)
);

create table if not exists public.daily_bonus_claims (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  membership_id bigint not null references public.premium_memberships(id),
  bonus_points integer not null check (bonus_points > 0),
  -- If the benefit is cash-denominated, record it separately in a future
  -- server-side payout table; do not treat BDT as points.
  claim_date date not null default (timezone('utc', now()))::date,
  created_at timestamptz not null default now(),
  unique (user_id, claim_date)
);

create table if not exists public.spin_claims (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  membership_id bigint not null references public.premium_memberships(id),
  reward_points integer not null check (reward_points >= 0),
  created_at timestamptz not null default now()
);

alter table public.premium_memberships enable row level security;
alter table public.daily_bonus_claims enable row level security;
alter table public.spin_claims enable row level security;

create policy "read own memberships" on public.premium_memberships
for select to authenticated using (auth.uid() = user_id);
create policy "read own bonus claims" on public.daily_bonus_claims
for select to authenticated using (auth.uid() = user_id);
create policy "read own spin claims" on public.spin_claims
for select to authenticated using (auth.uid() = user_id);

-- Intentionally no client-side INSERT/UPDATE/DELETE policies.
-- A server-side Edge Function must:
-- 1) verify the authenticated user;
-- 2) verify a confirmed payment before activating a membership;
-- 3) verify membership status='active' and current time within starts_at/ends_at;
-- 4) allow at most one daily bonus per user per UTC date (unique constraint);
-- 5) check active membership before issuing a spin;
-- 6) write the bonus/spin ledger atomically to prevent duplicate claims.
