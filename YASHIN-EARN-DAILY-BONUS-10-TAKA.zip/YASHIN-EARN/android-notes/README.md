Android APK এই ZIP-এর মধ্যে আগে থেকে তৈরি নেই। এটি Capacitor project source; APK বানাতে Android Studio-সহ কম্পিউটার প্রয়োজন। ধাপগুলো মূল README-BN.md-এ দেওয়া আছে।
